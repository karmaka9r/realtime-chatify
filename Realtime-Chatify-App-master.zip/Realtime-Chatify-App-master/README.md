
# Chatifyy

Chaatifyy is a Full Stack Chatting App.
Uses Socket.io for real time communication and stores user details in encrypted format in Mongo DB Database.
## Tech Stack

**Client:** React JS

**Server:** Node JS, Express JS

**Database:** Mongo DB
  
## Deployement
https://chaatifyy.onrender.com/

# Features

### Authenticaton
![Screenshot (182)](https://github.com/gouravmajumder2102/Realtime-Chatify-App/assets/87554983/4cd73fc4-4cd3-4688-a416-122fab23983d)

![Screenshot (183)](https://github.com/gouravmajumder2102/Realtime-Chatify-App/assets/87554983/58f59103-73d3-4fd4-ab08-4eb466b9ca33)

# Real Time Chatting
![Screenshot (179)](https://github.com/gouravmajumder2102/Realtime-Chatify-App/assets/87554983/e350a3cb-8b9c-420b-9c19-97aacec16da9)

# Group chats
![Screenshot (181)](https://github.com/gouravmajumder2102/Realtime-Chatify-App/assets/87554983/34fd9225-8e65-400a-aa71-44b60627e7c6)

# View Profile
![Screenshot (178)](https://github.com/gouravmajumder2102/Realtime-Chatify-App/assets/87554983/5a9c7517-f718-44b6-a119-581fa67b1a23)

# Made with ❤️ by
# Gourav Majumder

